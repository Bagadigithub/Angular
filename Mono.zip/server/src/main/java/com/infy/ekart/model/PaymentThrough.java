package com.infy.ekart.model;

public enum PaymentThrough {

	DEBIT_CARD, CREDIT_CARD, CASH_ON_DELIVERY
}
