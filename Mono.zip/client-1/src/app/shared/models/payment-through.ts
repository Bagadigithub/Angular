export enum PaymentThrough {
    DEBIT_CARD = "Debit Card",
    CREDIT_CARD = "Credit Card",
    CASH_ON_DELIVERY = "Cash On Delivery"
}