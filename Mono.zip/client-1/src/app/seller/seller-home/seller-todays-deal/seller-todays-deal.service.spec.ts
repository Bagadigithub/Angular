// import { TestBed } from '@angular/core/testing';

// import { SellerTodaysDealService } from './seller-todays-deal.service';

// describe('SellerTodaysDealService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: SellerTodaysDealService = TestBed.get(SellerTodaysDealService);
//     expect(service).toBeTruthy();
//   });
// });
